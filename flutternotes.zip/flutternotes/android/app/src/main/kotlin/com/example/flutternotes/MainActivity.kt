package com.example.flutternotes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
